function calculatePercentageOff(price, comparePrice) {
    const percentageOff = ((comparePrice - price) / comparePrice) * 100;
    return Math.round(percentageOff) + '% off';
}

// Fetch product data from local JSON file
fetch('product.json')
    .then(response => response.json())
    .then(data => {
        // Populate product details
        document.querySelector('.vendor').textContent = data.product.vendor;
        document.querySelector('.title').textContent = data.product.title;
        document.querySelector('.price').textContent = $${data.product.price};
        document.querySelector('.compare-price').textContent = Compare at $${data.product.compareAtPrice};
        document.querySelector('.percentage-off').textContent = calculatePercentageOff(data.product.price, data.product.compareAtPrice);

        // Populate color selector
        const colorSelector = document.querySelector('.color-selector');
        data.product.colors.forEach(color => {
            const option = document.createElement('option');
            option.value = color;
            option.textContent = color;
            colorSelector.appendChild(option);
        });

        // Populate size selector
        const sizeSelector = document.querySelector('.size-selector');
        data.product.sizes.forEach(size => {
            const option = document.createElement('option');
            option.value = size;
            option.textContent = size;
            sizeSelector.appendChild(option);
        });

        // Event listener for add to cart button
        document.querySelector('.add-to-cart').addEventListener('click', () => {
            // Get selected variant data
            const selectedColor = document.querySelector('.color-selector').value;
            const selectedSize = document.querySelector('.size-selector').value;
            const selectedQuantity = document.querySelector('.quantity-selector').value;

            // Display add to cart message
            const message = document.querySelector('.add-to-cart-message');
            message.textContent = Added to cart: ${selectedQuantity} x ${selectedSize} ${selectedColor} ${data.product.title};
            message.style.display = 'block';
        });
    })
    .catch(error => console.error('Error fetching product data:', error));